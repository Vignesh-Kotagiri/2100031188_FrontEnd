# 2100030232_Frontend
Saferteck task
# 1.	Dynamic Form Generation
You are tasked with creating a dynamic form builder where users can add and remove form fields (text inputs, checkboxes, radio buttons) on the fly. Implement in JavaScript would you use to manage the form elements dynamically?
# 2.	Interactive Data Table
Create an interactive data table that allows users to sort columns, filter rows, and paginate the results. Implement in JavaScript to handle large datasets efficiently and provide a smooth user experience.
# 3.	Extraction of words
 
As the above image you are write a JavaScript program to take the text out of a paragraph tag and place it behind words longer than eight characters with a highlighted backdrop. Determining the beginning and end of a word in a string can be challenging due to various symbols, gaps, and other irregularities. However, since the rule was limited to terms with more than eight characters, we can take a more flexible approach.

